import React from 'react';
export default function App(){
  return <div className="p-4 text-xl">Broker Frontend Running</div>;
}
